-- Forever 16001 APIs: Ketho/wow-ui-source-forever, branch forever,
-- InstanceDocumentation.lua and SystemDocumentation.lua. No encounter events,
-- invented disk markers, network access, roster data, or live SavedVariables IPC.
local addonName = ...
local frame = CreateFrame("Frame")
local MAX_SESSIONS = 128
local MAX_CHARACTERS = 50
local MIN_TIME, MAX_TIME = 946684800000, 4102444800000
local ready, inWorld, firstWorld = false, false, true
local reloadVisit, leftAt = false, nil
local current, pending
local generation, nextLogCall = 0, 0
local callingLogger = false

local function integer(value, minimum, maximum)
    return type(value) == "number" and value == math.floor(value)
        and value >= minimum and value <= maximum
end

local function text(value, maximum)
    return type(value) == "string" and #value > 0 and #value <= maximum
        and not string.find(value, "[%c]")
        and not string.find(value, "^%s") and not string.find(value, "%s$")
end

local function playerGuid(value)
    return text(value, 96) and (string.match(value, "^Player%-%d+%-%x+$")
        or (#value == 18 and string.match(value, "^0x0000%x+$")
            and value ~= "0x0000000000000000"))
end

local function projectSession(value)
    if type(value) ~= "table" or not text(value.id, 96)
        or not string.match(value.id, "^[%w_-]+$")
        or (value.kind ~= "party" and value.kind ~= "raid")
        or not integer(value.instanceId, 0, 2147483647)
        or not integer(value.difficultyId, 0, 2147483647)
        or not text(value.name, 160) or not playerGuid(value.playerGuid)
        or not text(value.realm, 96)
        or not integer(value.startedAt, MIN_TIME, MAX_TIME)
        or (value.endedAt ~= nil and not integer(value.endedAt, value.startedAt, MAX_TIME)) then
        return nil
    end
    return {
        id = value.id, kind = value.kind, instanceId = value.instanceId,
        difficultyId = value.difficultyId, name = value.name,
        startedAt = value.startedAt, endedAt = value.endedAt,
        playerGuid = value.playerGuid, realm = value.realm,
    }
end

local function characterGuid(value)
    if not text(value, 96) then return false end
    local lower = string.lower(value)
    return (string.match(lower, "^player%-%d+%-%x+$")
        and not string.match(lower, "^player%-%d+%-0+$"))
        or (#lower == 18 and string.match(lower, "^0x0000%x+$")
            and lower ~= "0x0000000000000000")
end

local function itemStringMatches(value, itemId)
    if not text(value, 2048) then return false end
    local id, suffix = string.match(value, "^item:(%d+)(.*)$")
    return id and tonumber(id) == itemId
        and (suffix == "" or (string.sub(suffix, 1, 1) == ":"
            and not string.find(suffix, "[^%d:%-]")))
end

local function projectEquipment(value)
    if type(value) ~= "table" or not integer(value.slot, 1, 19)
        or not integer(value.itemId, 0, 2147483647) then return end
    if value.itemId == 0 then
        if value.itemString ~= nil or value.name ~= nil
            or value.itemLevel ~= nil or value.quality ~= nil then return end
    elseif not itemStringMatches(value.itemString, value.itemId) then
        return
    end
    if (value.name ~= nil and not text(value.name, 240))
        or (value.itemLevel ~= nil and (type(value.itemLevel) ~= "number"
            or value.itemLevel ~= value.itemLevel
            or value.itemLevel < 0 or value.itemLevel > 100000))
        or (value.quality ~= nil and not integer(value.quality, 0, 7)) then return end
    return {
        slot = value.slot, itemId = value.itemId, itemString = value.itemString,
        name = value.name, itemLevel = value.itemLevel, quality = value.quality,
    }
end

local function projectCharacter(value, at)
    if type(value) ~= "table" or not characterGuid(value.guid)
        or not text(value.name, 80) or not text(value.realm, 96)
        or not integer(value.capturedAt, MIN_TIME, MAX_TIME)
        or (at and value.capturedAt > at + 300000)
        or (value.class ~= nil and not text(value.class, 60))
        or (value.level ~= nil and not integer(value.level, 1, 1000))
        or type(value.equipment) ~= "table" then return end
    local equipment, seen, count = {}, {}, 0
    for key, row in pairs(value.equipment) do
        count = count + 1
        if count > 19 or not integer(key, 1, 19) then return end
        local projected = projectEquipment(row)
        if not projected or seen[projected.slot] then return end
        seen[projected.slot] = true
        equipment[#equipment + 1] = projected
    end
    for index = 1, count do
        if value.equipment[index] == nil then return end
    end
    table.sort(equipment, function(a, b) return a.slot < b.slot end)
    return {
        guid = value.guid, name = value.name, realm = value.realm,
        class = value.class, level = value.level, capturedAt = value.capturedAt,
        equipment = equipment,
    }
end

local function retainCharacter(characters, candidate)
    local guid, realm = string.lower(candidate.guid), candidate.realm
    for index, previous in ipairs(characters) do
        if string.lower(previous.guid) == guid and previous.realm == realm then
            if candidate.capturedAt >= previous.capturedAt then characters[index] = candidate end
            return
        end
    end
    characters[#characters + 1] = candidate
    if #characters > MAX_CHARACTERS then
        local oldest = 1
        for index = 2, #characters do
            if characters[index].capturedAt < characters[oldest].capturedAt then oldest = index end
        end
        table.remove(characters, oldest)
    end
end

local function initialize()
    local previous = type(AurifyDB) == "table" and AurifyDB
    local sessions, seen = {}, {}
    if previous and previous.version == 1 and type(previous.sessions) == "table" then
        local count = #previous.sessions
        for index = math.max(1, count - MAX_SESSIONS + 1), count do
            local session = projectSession(previous.sessions[index])
            if session and not seen[session.id] then
                sessions[#sessions + 1] = session
                seen[session.id] = true
            end
        end
    end
    local characters = {}
    if previous and previous.version == 1 and previous.characterSchemaVersion == 1
        and type(previous.characters) == "table" then
        local at = type(time) == "function" and time() * 1000
        if not integer(at, MIN_TIME, MAX_TIME) then at = nil end
        for key, value in pairs(previous.characters) do
            if integer(key, 1, 2147483647) then
                local character = projectCharacter(value, at)
                if character then retainCharacter(characters, character) end
            end
        end
    end
    AurifyDB = {
        version = 1, sessions = sessions,
        characterSchemaVersion = 1, characters = characters,
    }
    ready = true
end

local function now()
    local value = time() * 1000
    if integer(value, MIN_TIME, MAX_TIME) then return value end
end

-- Forever's Camelot PaperDollFrame uses C_PaperDollInfo slot-name lookup and
-- ItemLocation:CreateFromEquipmentSlot. API inventory indices are not our
-- canonical roster slot numbers, so resolve each named slot explicitly.
local equipmentSlots = {
    "HeadSlot", "NeckSlot", "ShoulderSlot", "ShirtSlot", "ChestSlot",
    "WaistSlot", "LegsSlot", "FeetSlot", "WristSlot", "HandsSlot",
    "Finger0Slot", "Finger1Slot", "Trinket0Slot", "Trinket1Slot",
    "BackSlot", "MainHandSlot", "SecondaryHandSlot", "RangedSlot", "TabardSlot",
}

local function query(fn, ...)
    if type(fn) ~= "function" then return false end
    return pcall(fn, ...)
end

local function captureEquipment(slot, slotName)
    if type(C_PaperDollInfo) ~= "table" or type(ItemLocation) ~= "table"
        or type(C_Item) ~= "table" then return end
    local slotOK, inventorySlot = query(C_PaperDollInfo.GetInventorySlotInfo, slotName)
    if not slotOK or not integer(inventorySlot, 1, 2147483647) then return end
    local locationOK, location = query(ItemLocation.CreateFromEquipmentSlot, ItemLocation, inventorySlot)
    if not locationOK or type(location) ~= "table" then return end
    local existsOK, exists = query(C_Item.DoesItemExist, location)
    if not existsOK or type(exists) ~= "boolean" then return end
    -- The documented existence predicate is distinct from item-cache state.
    -- A failed query, nil link, or pending metadata never proves an empty slot.
    if not exists then return { slot = slot, itemId = 0 } end
    local linkOK, link = query(C_Item.GetItemLink, location)
    if not linkOK or type(link) ~= "string" then return end
    local itemString = string.match(link, "|H(item:[^|]+)|h") or link
    local itemId = tonumber(string.match(itemString, "^item:(%d+)"))
    if not integer(itemId, 1, 2147483647) or not itemStringMatches(itemString, itemId) then return end
    local row = { slot = slot, itemId = itemId, itemString = itemString }
    local infoOK, name, _, quality, itemLevel = query(C_Item.GetItemInfo, link)
    if infoOK then
        if text(name, 240) then row.name = name end
        if integer(quality, 0, 7) then row.quality = quality end
        if type(itemLevel) == "number" and itemLevel >= 0 and itemLevel <= 100000 then
            row.itemLevel = itemLevel
        end
    end
    return row
end

local function captureCharacter()
    if not ready then return end
    local guidOK, guid = query(UnitGUID, "player")
    if not guidOK or not characterGuid(guid) then return end
    -- Forever PlayerScript documents class/name/realm/level at 2/6/7/8.
    -- No target, party, raid, guild, inspect, or account roster is queried.
    local infoOK, _, class, _, _, _, name, realm, level = query(GetPlayerInfoByGUID, guid)
    if not infoOK or not text(name, 80) then return end
    if realm == nil or realm == "" then
        local realmOK, playerRealm = query(GetRealmName)
        if realmOK then realm = playerRealm end
    end
    if not text(realm, 96) then return end
    local equipment = {}
    for slot, slotName in ipairs(equipmentSlots) do
        local row = captureEquipment(slot, slotName)
        if row then equipment[#equipment + 1] = row end
    end
    local sameOK, sameGuid = query(UnitGUID, "player")
    local at = now()
    if not sameOK or sameGuid ~= guid or not at then return end
    retainCharacter(AurifyDB.characters, {
        guid = guid, name = name, realm = realm, capturedAt = at,
        class = text(class, 60) and class or nil,
        level = integer(level, 1, 1000) and level or nil,
        equipment = equipment,
    })
end

local captureScheduled = false
local function cancelCharacterCapture()
    captureScheduled = false
    frame:SetScript("OnUpdate", nil)
end

local function scheduleCharacterCapture()
    if not ready or not inWorld or captureScheduled then return end
    captureScheduled = true
    local elapsedTotal = 0
    frame:SetScript("OnUpdate", function(_, elapsed)
        elapsedTotal = elapsedTotal + elapsed
        if elapsedTotal < 0.25 then return end
        cancelCharacterCapture()
        if inWorld then captureCharacter() end
    end)
end

local function sameInstance(session, kind, instanceId, difficultyId, guid, realm)
    return session and session.endedAt == nil and session.kind == kind
        and session.instanceId == instanceId and session.difficultyId == difficultyId
        and session.playerGuid == guid and session.realm == realm
end

local function cancelStart()
    generation = generation + 1
    pending = nil
end

-- /combatlog calls the global LoggingCombat (Forever SlashCommands.lua).
-- Secure hooks see ordinary external setters, including explicit nil setters.
-- They cannot prove that other addons did not cache a pre-hook function reference.
-- Therefore Aurify NEVER calls LoggingCombat(false), even after its own enable:
-- existing/manual logging cannot be accidentally stopped on exit or UI reload.
if type(hooksecurefunc) == "function" and type(LoggingCombat) == "function" then
    pcall(hooksecurefunc, "LoggingCombat", function(...)
        if callingLogger then return end
        nextLogCall = GetTime() + 11
        if select("#", ...) > 0 then cancelStart() end
    end)
end

local tryStart
local function scheduleStart(delay, token)
    if not C_Timer or type(C_Timer.After) ~= "function" then
        pending = nil
        return
    end
    if pending.scheduled then return end
    pending.scheduled = true
    C_Timer.After(delay, function()
        if pending and generation == token then
            pending.scheduled = false
            tryStart(token)
        end
    end)
end

tryStart = function(token)
    if not pending or pending.scheduled or token ~= generation or not inWorld then return end
    local inside, kind = IsInInstance()
    if not inside or (kind ~= "party" and kind ~= "raid") then
        cancelStart()
        return
    end
    local wait = nextLogCall - GetTime()
    if wait > 0 then
        scheduleStart(wait, token)
        return
    end
    -- At most three attempts, >=11s apart; each uses <=2 of the shared 5/10s
    -- allowance. A nil return is UNKNOWN, not permission to change the logger.
    pending.attempts = pending.attempts + 1
    nextLogCall = GetTime() + 11
    callingLogger = true
    local ok, state = pcall(LoggingCombat)
    if ok and state == false then ok, state = pcall(LoggingCombat, true) end
    callingLogger = false
    if not ok or state == true or pending.attempts >= 3 then
        pending = nil
    else
        scheduleStart(11, token)
    end
end

local function beginLogging()
    cancelStart()
    if type(LoggingCombat) ~= "function" then return end
    pending = { attempts = 0 }
    tryStart(generation)
end

local function finish(at)
    cancelStart()
    if current and at and at >= current.startedAt then current.endedAt = at end
    current = nil
end

local function newId(at, instanceId)
    local prefix = string.format("%.0f-%d-", at, instanceId)
    local suffix = 1
    while true do
        local id, found = prefix .. suffix, false
        for _, session in ipairs(AurifyDB.sessions) do
            if session.id == id then found = true; break end
        end
        if not found then return id end
        suffix = suffix + 1
    end
end

local function reconcile()
    if not ready or not inWorld then return end
    local at = now()
    if not at then return end
    local inside, kind = IsInInstance()
    if not inside or (kind ~= "party" and kind ~= "raid") then
        if current then finish(leftAt or at) end
        leftAt, reloadVisit = nil, false
        return
    end
    local name, instanceType, difficultyId, _, _, _, _, instanceId = GetInstanceInfo()
    local guid, realm = UnitGUID("player"), GetRealmName()
    -- Do not invent zero IDs or identities while the client is transitioning.
    if instanceType ~= kind or not integer(instanceId, 0, 2147483647)
        or not integer(difficultyId, 0, 2147483647) or not text(name, 160)
        or not playerGuid(guid) or not text(realm, 96) then return end
    if sameInstance(current, kind, instanceId, difficultyId, guid, realm) then
        leftAt = nil
        return
    end
    if current then finish(leftAt or at) end
    leftAt = nil
    if reloadVisit then
        -- Only the most recent visit by this character can survive a UI reload.
        -- Initial login never resumes a stale open visit after logout/crash.
        for index = #AurifyDB.sessions, 1, -1 do
            local session = AurifyDB.sessions[index]
            if session.playerGuid == guid and session.realm == realm then
                if sameInstance(session, kind, instanceId, difficultyId, guid, realm)
                    and session.startedAt <= at then current = session end
                break
            end
        end
    end
    reloadVisit = false
    if not current then
        current = {
            id = newId(at, instanceId), kind = kind, instanceId = instanceId,
            difficultyId = difficultyId, name = name, startedAt = at,
            playerGuid = guid, realm = realm,
        }
        local sessions = AurifyDB.sessions
        if #sessions >= MAX_SESSIONS then table.remove(sessions, 1) end
        sessions[#sessions + 1] = current
    end
    beginLogging()
end

frame:SetScript("OnEvent", function(_, event, ...)
    if event == "ADDON_LOADED" then
        if ... == addonName then initialize() end
    elseif event == "PLAYER_ENTERING_WORLD" then
        if not ready then initialize() end
        local _, reloading = ...
        inWorld = true
        if firstWorld then reloadVisit = reloading == true end
        reconcile()
        scheduleCharacterCapture()
        firstWorld = false
        if pending then tryStart(generation) end
    elseif event == "PLAYER_LEAVING_WORLD" then
        -- Preserve the observed departure until the destination is known.
        -- This event also fires during logout/reload, so it cannot end a visit.
        if current then leftAt = now() end
        cancelCharacterCapture()
        captureCharacter()
        inWorld = false
    elseif event == "PLAYER_LOGOUT" then
        -- Also fires for /reload. Never fabricate an end/restart at this event.
        -- Client persistence writes AurifyDB now; it is not a live IPC channel.
        cancelCharacterCapture()
        captureCharacter() -- Still query the player after PLAYER_LEAVING_WORLD.
        inWorld = false
    elseif event == "PLAYER_EQUIPMENT_CHANGED" then
        scheduleCharacterCapture()
    elseif event == "GET_ITEM_INFO_RECEIVED" or event == "ITEM_DATA_LOAD_RESULT" then
        local _, success = ...
        if success == true then scheduleCharacterCapture() end
    else
        reconcile()
    end
end)

-- Unknown events can throw on Forever; only evidenced events, guarded anyway.
for _, event in ipairs({ "ADDON_LOADED", "PLAYER_ENTERING_WORLD",
    "PLAYER_LEAVING_WORLD", "PLAYER_LOGOUT", "ZONE_CHANGED_NEW_AREA",
    "GROUP_ROSTER_UPDATE", "PLAYER_EQUIPMENT_CHANGED",
    "GET_ITEM_INFO_RECEIVED", "ITEM_DATA_LOAD_RESULT" }) do
    pcall(frame.RegisterEvent, frame, event)
end
